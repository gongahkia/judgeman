# Judgeman Release Guide

## What Ships

The current store-safe release of Judgeman is a local-only ELIT judgment readability extension.

Included capabilities:

- Detect supported ELIT judgment pages.
- Show a compact floating launcher on judgment pages.
- Open a non-destructive reader overlay for the current judgment.
- Extract structured case JSON locally and copy it to the clipboard.

Excluded from the current release:

- Gemini or any other AI summarization/diagram features.
- API-key settings and options UI.
- Third-party network calls based on page content.

The deferred AI path remains in `judgeman_v4/experimental_ai/` and is not part of the shipped store artifacts.

## Local Development

Prerequisites:

- Node.js 20+
- npm 11+
- Python 3 with Pillow available
- Xcode command-line tools for Safari project generation

Install dependencies:

```bash
npm install
```

Generate icons:

```bash
npm run icons
```

Build all browser artifacts:

```bash
npm run build
```

Run tests:

```bash
npm test
```

Generated outputs:

- Chrome artifact: `dist/chrome`
- Firefox artifact: `dist/firefox`
- Safari source artifact: `dist/safari`

Generate the AMO submission bundle:

```bash
npm run package:firefox
```

That command creates:

- `submission/firefox/judgeman-firefox-4.1.0.zip`
- `submission/firefox/judgeman-firefox-source-4.1.0.zip`
- `submission/firefox/amo-metadata.json`

## Loading the Extension Locally

### Chrome

1. Open `chrome://extensions/`
2. Enable Developer mode
3. Click Load unpacked
4. Select `dist/chrome`

### Firefox

1. Open `about:debugging#/runtime/this-firefox`
2. Click Load Temporary Add-on
3. Select `dist/firefox/manifest.json`

### Safari macOS

1. Run `npm run safari:project`
2. Open `safari/Judgeman/Judgeman.xcodeproj`
3. Set your Apple development team in Xcode
4. Build and run the `Judgeman` app target
5. Enable the extension in Safari Settings > Extensions

## Build and Packaging Commands

Build one browser target only:

```bash
npm run build:chrome
npm run build:firefox
npm run package:firefox
npm run lint:firefox
npm run build:safari
```

Generate the Safari macOS app wrapper:

```bash
npm run safari:project
```

Equivalent Make targets:

```bash
make build
make build-chrome
make build-firefox
make package-firefox
make lint-firefox
make build-safari
make safari-project
make test
```

## Firefox Submission

Use the generated files under `submission/firefox`.

### Exact Files to Submit to AMO

- Upload `submission/firefox/judgeman-firefox-4.1.0.zip` as the add-on package.
- If AMO asks for source code because this repository uses a build step, upload `submission/firefox/judgeman-firefox-source-4.1.0.zip` as the source archive.
- `submission/firefox/amo-metadata.json` is optional. Use it only if you later automate submission with `web-ext sign`; it is not the file you upload in the standard AMO web form.

### How the Firefox Add-on Package Is Built

- The installable AMO package is a ZIP of the files inside `dist/firefox`, with `manifest.json` at the archive root.
- The Firefox manifest includes a stable add-on ID through `browser_specific_settings.gecko.id`.
- The Firefox manifest declares `data_collection_permissions.required = ["none"]`.

### Firefox Upload Flow

1. Run `npm run package:firefox`.
2. Run `npm run lint:firefox`.
3. Open the AMO developer submission page.
4. Upload `submission/firefox/judgeman-firefox-4.1.0.zip`.
5. If AMO asks whether a source-code archive is required because of the build tooling, answer yes and upload `submission/firefox/judgeman-firefox-source-4.1.0.zip`.
6. Paste the listing description, privacy-policy URL, and reviewer notes from this document into the AMO listing fields.

### Firefox Add-on Identity

- Current generated add-on ID: `judgeman@gongahkia.github.io`
- Override it at build time if needed with `JUDGEMAN_FIREFOX_ADDON_ID=your-id@example.com npm run package:firefox`

## Reviewer Notes

### Supported URL Patterns

- `https://www.elitigation.sg/gd/*`
- `https://www.elitigation.sg/gdviewer/*`

### Sample Public ELIT Judgment URLs

- `https://www.elitigation.sg/gd/s/2009_SGCA_3`

If that sample URL changes or becomes unavailable, any public ELIT judgment under `/gd/` or `/gdviewer/` is sufficient for reviewer testing.

### Reviewer Test Steps

1. Install the extension.
2. Open a supported ELIT judgment URL.
3. Confirm a small `Judgeman` launcher appears near the top-left corner.
4. Click the launcher and choose `Toggle readable view`.
5. Confirm the reader opens as a full-page overlay while the original ELIT DOM remains intact underneath.
6. Close the reader and verify the original page remains functional.
7. Open the extension popup and click `Copy case JSON`.
8. Paste the clipboard contents into a text editor and confirm the extension copied structured metadata and judgment sections.

### Expected Permissions

- `activeTab`

The shipped store-safe build does not request storage permissions, scripting permissions, or third-party host access.

### Firefox Reviewer Note

The Firefox submission includes a separate source archive because the packaged add-on ZIP is generated from source files using local build scripts in this repository.

## Privacy Policy

Judgeman is a local-only readability extension for public ELIT judgment pages.

Privacy commitments for the shipped store-safe release:

- Judgeman reads the current ELIT judgment page in order to render a local readable view and produce a local structured export.
- Judgeman does not sell user data.
- Judgeman does not transmit judgment page content to third-party services.
- Judgeman does not collect browsing history beyond the active ELIT judgment page needed for the feature to function.
- Judgeman does not store API keys or other user secrets in the shipped store-safe build.
- Judgeman only acts on supported ELIT judgment URLs.
- Judgeman only copies case JSON when the user explicitly clicks the export button.

Data handled by the shipped store-safe build:

- ELIT judgment title
- ELIT case metadata shown on the page
- ELIT legal issues shown on the page
- ELIT judgment body text shown on the page

Purpose of that data handling:

- render a readable overlay
- generate a structured local JSON export

Retention:

- No judgment data is retained by the developer or sent to a remote server in the shipped store-safe build.
- Copied JSON is placed on the local system clipboard only after an explicit user action.

Support contact:

- GitHub issues: `https://github.com/gongahkia/judgeman/issues`

Recommended public privacy-policy URL for store listings:

- Host this section from `README2.md` at a stable public URL before submission.
- A simple GitHub Pages or project website page is sufficient as long as the text remains accessible without authentication.

## Store Metadata Guidance

Use short, narrow descriptions that match the shipped behavior.

Recommended short description:

- Readable ELIT judgments with local structured export.

Recommended longer description points:

- Reformats public ELIT judgments into a focused reading overlay.
- Extracts case metadata, legal issues, and judgment sections locally.
- Copies structured case JSON on request.
- Does not send judgment content to third parties in this release.

Do not mention AI, Gemini, or API-key support in the store metadata for this release.
