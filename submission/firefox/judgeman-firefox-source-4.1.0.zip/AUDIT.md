# Judgeman Store-Readiness Audit

## Executive Summary

This repository now contains a store-safe first-release path for Chrome, Firefox, and Safari macOS centered on a single purpose: make ELIT judgment pages easier to read and export locally as structured case JSON.

The original repository was not submission-ready. The implemented remediation work addressed the most likely marketplace blockers:

- Removed third-party AI calls and all API-key storage from the live build.
- Removed the background worker from the live build, so the shipped popup communicates directly with the active tab.
- Replaced destructive `document.body.innerHTML` replacement with a non-destructive reader overlay that leaves the original ELIT DOM mounted.
- Reduced automatic access to ELIT judgment URLs only.
- Added generated browser-specific manifests and packaging outputs for Chrome, Firefox, and Safari source artifacts.
- Added a real Safari macOS wrapper project generated via Apple tooling.
- Added local extraction and overlay regression tests.

The root `README.md` was intentionally left unchanged. All current audit and release guidance lives in this file and in `README2.md`.

## Current Submission Posture

### Chrome Web Store

Status: materially improved and likely reviewable after listing metadata and privacy-policy hosting are completed.

What changed for Chrome review:

- Live build now requests only `activeTab`.
- Live build no longer declares Gemini or other third-party hosts.
- Live build no longer stores API keys in extension storage.
- Live build no longer transmits page content off-device.
- The feature set is narrowly scoped to readability plus local export.

Remaining submission tasks:

- Host the privacy-policy text from `README2.md` at a stable public URL.
- Package and upload the generated `dist/chrome` artifact.
- Provide reviewer notes using the sample ELIT judgment URLs listed in `README2.md`.

### Firefox Add-ons

Status: materially improved and likely reviewable after signing and metadata completion.

What changed for Firefox review:

- Removed the live MV3 background service worker path that would have complicated Firefox compatibility.
- Added Firefox-specific manifest output with:
  - `browser_specific_settings.gecko.id`
  - `browser_specific_settings.gecko.strict_min_version`
  - `browser_specific_settings.gecko.data_collection_permissions.required = ["none"]`
- Live build now has no third-party data transmission and no sync-stored secrets.

Remaining submission tasks:

- Generate the AMO-ready Firefox submission bundle with `npm run package:firefox`.
- Validate the generated Firefox artifact with `npm run lint:firefox`.
- Upload `submission/firefox/judgeman-firefox-4.1.0.zip` as the add-on package.
- Upload `submission/firefox/judgeman-firefox-source-4.1.0.zip` if AMO requests the source archive because of the build step.
- Ensure the AMO listing text matches the shipped local-only behavior exactly.
- Provide reviewer notes and supported URL patterns from `README2.md`.

### Safari App Store

Status: first viable packaging path now exists, but Apple review still requires a full signing and App Store Connect pass.

What changed for Safari distribution:

- Added a generated Safari web extension source artifact at `dist/safari`.
- Added a macOS Safari wrapper project at `safari/Judgeman` using Apple’s converter tooling.
- Replaced the default placeholder app screen with onboarding, enablement guidance, support, and privacy links.

Remaining submission tasks:

- Open `safari/Judgeman/Judgeman.xcodeproj` in Xcode.
- Configure signing, team, bundle identifiers, and App Sandbox details as needed.
- Set App Store Connect privacy fields to match the shipped local-only behavior.
- Archive and validate the app from Xcode before App Store submission.

## Findings and Remediations

### Fixed

1. Overbroad data exposure and third-party transmission

- Previous state:
  - live manifest requested ELIT-wide access and Gemini host access
  - background worker sent extracted judgment text to Gemini
  - options UI stored API keys in extension storage
- Implemented remediation:
  - store-safe build removed AI runtime from the live artifact
  - previous AI files moved to `judgeman_v4/experimental_ai/`
  - generated manifests exclude Gemini hosts, storage, and scripting permissions

2. Firefox compatibility risk from background worker design

- Previous state:
  - the live extension depended on a background service worker
- Implemented remediation:
  - popup now uses direct `tabs.query()` and `tabs.sendMessage()` to the active tab
  - live build has no background script
  - Firefox-specific manifest output is generated separately

3. Runtime fragility from destructive page replacement

- Previous state:
  - readable mode replaced `document.body.innerHTML`, which could discard page state and event handlers
- Implemented remediation:
  - live build now mounts a fixed reader overlay rooted outside the ELIT body
  - original ELIT DOM remains intact during readable view
  - regression test added for overlay toggle preserving the original DOM

4. Packaging drift and stale release guidance

- Previous state:
  - root `Makefile` pointed at archived Java tooling
  - there was only one hand-maintained live manifest
- Implemented remediation:
  - added Node-based build tooling for generated browser artifacts
  - added icon generation tooling
  - added Safari project generation tooling
  - updated `Makefile` to target the live extension path

### Deferred by Design

1. Gemini/BYOK features

- Deferred because they materially increase approval risk across all three marketplaces.
- Preserved under `judgeman_v4/experimental_ai/` for future hardening.

2. iPhone/iPad Safari packaging

- Deferred because the approved scope for this remediation was Safari macOS first.

## Permission and Data-Flow Inventory

### Shipped Store-Safe Build

Permission inventory:

- `activeTab`

Automatic site access:

- ELIT judgments only:
  - `https://www.elitigation.sg/gd/*`
  - `https://www.elitigation.sg/gdviewer/*`

Data flow:

- Reads ELIT page DOM locally in the content script.
- Builds a structured case object locally.
- Renders a local reader overlay locally.
- Copies structured case JSON to the clipboard when explicitly requested.
- Does not send judgment text or browsing data to third parties.
- Does not store user-entered secrets.

### Deferred AI Path

Risk inventory if re-enabled later:

- Sends extracted page content to Gemini.
- Stores API keys client-side.
- Requires updated privacy disclosures and consent flows.
- Requires revisiting Chrome user-data posture and Firefox data-collection declarations.

## Blocking vs Non-Blocking Checklist

### Blocking Before Store Submission

- Host the privacy policy from `README2.md` at a stable public URL.
- Fill in final listing text and screenshots for Chrome, AMO, and App Store Connect.
- Complete manual smoke testing on current Chrome, Firefox, and Safari macOS builds.
- Complete code signing and archive flow for the Safari Xcode project.

### Non-Blocking but Recommended

- Add more real-world ELIT fixtures covering judgments with missing metadata rows.
- Add accessibility labels and keyboard traps tests for the reader overlay.
- Add CI to run `npm run build` and `npm test` automatically.

## Verification State

The following checks were run after implementation:

- `npm run build`
- `npm run package:firefox`
- `npm run lint:firefox`
- `npm test`
- `npm run safari:project`

Artifacts now present:

- `dist/chrome`
- `dist/firefox`
- `dist/safari`
- `safari/Judgeman`

Firefox submission artifacts generated by the packaging flow:

- `submission/firefox/judgeman-firefox-4.1.0.zip`
- `submission/firefox/judgeman-firefox-source-4.1.0.zip`
- `submission/firefox/amo-metadata.json`
