# Firefox AMO Source Package

This archive contains the source used to generate the AMO upload package for Judgeman 4.1.0.

## Files Generated for Submission

- Add-on upload: `submission/firefox/judgeman-firefox-4.1.0.zip`
- Source-code upload: `submission/firefox/judgeman-firefox-source-4.1.0.zip`

## Rebuild Steps

```bash
npm install
npm run icons
npm run build:firefox
npm run package:firefox
```

## Exact Firefox Add-on ID

`judgeman@gongahkia.github.io`

## Expected Firefox Build Output

The generated extension package is built from the contents of `dist/firefox`, with `manifest.json` at the archive root.
